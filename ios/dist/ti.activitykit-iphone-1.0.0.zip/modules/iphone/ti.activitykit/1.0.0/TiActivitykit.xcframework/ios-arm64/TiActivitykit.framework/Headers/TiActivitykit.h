//
//  TiActivitykit.h
//  ti.activitykit
//
//  Created by Your Name
//  Copyright (c) 2025 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiActivitykit.
FOUNDATION_EXPORT double TiActivitykitVersionNumber;

//! Project version string for TiActivitykit.
FOUNDATION_EXPORT const unsigned char TiActivitykitVersionString[];

#import "TiActivitykitModuleAssets.h"
